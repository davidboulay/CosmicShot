"""Annotation objects. All coordinates are in the cropped image's pixel space.

Each annotation knows how to draw itself onto a cairo context. The `ctx` passed to
draw() exposes `blur_surface` (a pre-blurred copy of the base image) used by the
blur/pixelate tool.

Annotations also expose a small geometry protocol used by the editor's Select tool:
  bbox()             -> (x, y, w, h) bounding box
  set_bbox(x,y,w,h)  -> reshape to a new bounding box (box-style shapes)
  move(dx, dy)       -> translate
  contains(px,py,t)  -> is the point within tolerance t of the shape?
  handle_style       -> "box" (8 corner/edge handles), "endpoints" (start/end),
                        or "none" (movable/deletable but never resized)
  endpoints()/set_endpoint(name, x, y)  -> for line/arrow style shapes
"""
import math
from dataclasses import dataclass, field
from typing import List, Tuple, Optional

import cairo
import gi
gi.require_version("Pango", "1.0")
gi.require_version("PangoCairo", "1.0")
from gi.repository import Pango, PangoCairo

from .config import hex_to_rgba

_PANGO_ALIGN = {
    "left": Pango.Alignment.LEFT,
    "center": Pango.Alignment.CENTER,
    "right": Pango.Alignment.RIGHT,
    "justify": Pango.Alignment.LEFT,  # justify uses LEFT + set_justify(True)
}


def _set_color(cr, hex_color, alpha=1.0):
    cr.set_source_rgba(*hex_to_rgba(hex_color, alpha))


_MEASURE_CR = None


def measure_cr():
    """A throwaway cairo context used to build Pango layouts outside of a draw
    (caret placement, click-to-index, selection geometry).

    Text uses `set_absolute_size`, so glyph metrics are in device units and do
    not depend on this surface's resolution — measurements here match what the
    canvas draws.
    """
    global _MEASURE_CR
    if _MEASURE_CR is None:
        _MEASURE_CR = cairo.Context(cairo.ImageSurface(cairo.FORMAT_ARGB32, 1, 1))
    return _MEASURE_CR


def _dist_to_segment(px, py, x0, y0, x1, y1):
    dx, dy = x1 - x0, y1 - y0
    if dx == 0 and dy == 0:
        return math.hypot(px - x0, py - y0)
    t = ((px - x0) * dx + (py - y0) * dy) / (dx * dx + dy * dy)
    t = max(0, min(1, t))
    return math.hypot(px - (x0 + t * dx), py - (y0 + t * dy))


class Annotation:
    handle_style = "box"

    def draw(self, cr, ctx):
        raise NotImplementedError

    # --- geometry protocol (sensible defaults; overridden where needed) ---
    def bbox(self):
        return (0, 0, 0, 0)

    def set_bbox(self, x, y, w, h):
        pass

    def move(self, dx, dy):
        x, y, w, h = self.bbox()
        self.set_bbox(x + dx, y + dy, w, h)

    def contains(self, px, py, tol):
        x, y, w, h = self.bbox()
        return (x - tol <= px <= x + w + tol) and (y - tol <= py <= y + h + tol)


# ----------------------------------------------------------- endpoint shapes
@dataclass
class Arrow(Annotation):
    x0: float; y0: float; x1: float; y1: float
    color: str = "#ff3b30"
    width: float = 4
    handle_style = "endpoints"

    def draw(self, cr, ctx):
        dx, dy = self.x1 - self.x0, self.y1 - self.y0
        length = math.hypot(dx, dy)
        if length < 1:
            return
        ang = math.atan2(dy, dx)
        w = self.width
        head_len = max(11, w * 3.4)     # length of the filled head
        head_w = max(7, w * 2.1)        # half-width of the head base
        _set_color(cr, self.color)
        cr.set_line_cap(1)
        cr.set_line_join(1)
        # shaft: stop just inside the head base so the join looks clean
        shaft_end = max(0.0, length - head_len * 0.85)
        cr.set_line_width(w)
        cr.move_to(self.x0, self.y0)
        cr.line_to(self.x0 + math.cos(ang) * shaft_end,
                   self.y0 + math.sin(ang) * shaft_end)
        cr.stroke()
        # filled triangular head
        bx = self.x1 - math.cos(ang) * head_len
        by = self.y1 - math.sin(ang) * head_len
        px, py = math.cos(ang + math.pi / 2), math.sin(ang + math.pi / 2)
        cr.move_to(self.x1, self.y1)
        cr.line_to(bx + px * head_w, by + py * head_w)
        cr.line_to(bx - px * head_w, by - py * head_w)
        cr.close_path()
        cr.fill()

    def bbox(self):
        x, y = min(self.x0, self.x1), min(self.y0, self.y1)
        return (x, y, abs(self.x1 - self.x0), abs(self.y1 - self.y0))

    def move(self, dx, dy):
        self.x0 += dx; self.y0 += dy; self.x1 += dx; self.y1 += dy

    def endpoints(self):
        return {"start": (self.x0, self.y0), "end": (self.x1, self.y1)}

    def set_endpoint(self, name, x, y):
        if name == "start":
            self.x0, self.y0 = x, y
        else:
            self.x1, self.y1 = x, y

    def contains(self, px, py, tol):
        return _dist_to_segment(px, py, self.x0, self.y0, self.x1, self.y1) \
            <= tol + self.width / 2


@dataclass
class Line(Arrow):
    """Same geometry as Arrow, without the arrowhead."""
    def draw(self, cr, ctx):
        _set_color(cr, self.color)
        cr.set_line_width(self.width)
        cr.set_line_cap(1)
        cr.move_to(self.x0, self.y0)
        cr.line_to(self.x1, self.y1)
        cr.stroke()


# ---------------------------------------------------------------- box shapes
@dataclass
class Rect(Annotation):
    x: float; y: float; w: float; h: float
    color: str = "#ff3b30"
    width: float = 4

    def draw(self, cr, ctx):
        _set_color(cr, self.color)
        cr.set_line_width(self.width)
        cr.set_line_join(1)
        cr.rectangle(self.x, self.y, self.w, self.h)
        cr.stroke()

    def bbox(self):
        return (self.x, self.y, self.w, self.h)

    def set_bbox(self, x, y, w, h):
        self.x, self.y, self.w, self.h = x, y, w, h

    def contains(self, px, py, tol):
        # outline shape: hit only near the border, so you can draw inside it
        t = tol + self.width / 2
        outer = (self.x - t <= px <= self.x + self.w + t
                 and self.y - t <= py <= self.y + self.h + t)
        inner = (self.x + t < px < self.x + self.w - t
                 and self.y + t < py < self.y + self.h - t)
        return outer and not inner


@dataclass
class Ellipse(Rect):
    def draw(self, cr, ctx):
        _set_color(cr, self.color)
        cr.set_line_width(self.width)
        cr.save()
        cr.translate(self.x + self.w / 2, self.y + self.h / 2)
        if self.w and self.h:
            cr.scale(self.w / 2, self.h / 2)
            cr.arc(0, 0, 1, 0, 2 * math.pi)
        cr.restore()
        cr.stroke()

    def contains(self, px, py, tol):
        # hit near the ellipse curve only (hollow interior is click-through)
        rx, ry = (self.w / 2) or 1, (self.h / 2) or 1
        cx, cy = self.x + rx, self.y + ry
        r = math.hypot((px - cx) / rx, (py - cy) / ry)
        band = (tol + self.width / 2) / max(1, min(rx, ry))
        return abs(r - 1) <= band


@dataclass
class Blur(Annotation):
    x: float; y: float; w: float; h: float

    def draw(self, cr, ctx):
        surf = getattr(ctx, "blur_surface", None)
        if surf is None or self.w <= 0 or self.h <= 0:
            return
        cr.save()
        cr.rectangle(self.x, self.y, self.w, self.h)
        cr.clip()
        cr.set_source_surface(surf, 0, 0)
        cr.paint()
        cr.restore()

    def bbox(self):
        return (self.x, self.y, self.w, self.h)

    def set_bbox(self, x, y, w, h):
        self.x, self.y, self.w, self.h = x, y, w, h


@dataclass
class Spotlight(Annotation):
    """A single focus rectangle. Each Spotlight is an independent annotation —
    selectable, movable and resizable on its own (its own frame/handles).

    Darkness must NOT compound when several spotlights overlap, so the dim layer
    is NOT drawn per-instance here; ``draw_combined()`` paints one dark layer
    with every spotlight's rect punched out. Both the editor and the exporter
    call it once and skip the per-instance draw().
    """
    x: float; y: float; w: float; h: float
    darkness: float = 0.6

    @staticmethod
    def draw_combined(cr, ctx, spots, extra_rect=None):
        """Paint one dark overlay over the whole image with the UNION of every
        spotlight's rectangle (plus an optional live draft rect) punched out.

        Overlapping focus areas merge into one bright region — they don't darken
        each other. Done by building the dim layer in a group and clearing the
        union of the focus rects (nonzero winding fills overlaps once)."""
        W = getattr(ctx, "img_w", 0)
        H = getattr(ctx, "img_h", 0)
        if not W or not H or (not spots and not extra_rect):
            return
        darkness = max([s.darkness for s in spots] + [0.6 if extra_rect else 0.0])
        rects = [(s.x, s.y, s.w, s.h) for s in spots]
        if extra_rect:
            rects.append(tuple(extra_rect))
        cr.save()
        cr.push_group()
        cr.set_source_rgba(0, 0, 0, max(0.0, min(0.95, darkness)))
        cr.rectangle(0, 0, W, H)
        cr.fill()
        cr.set_operator(cairo.OPERATOR_CLEAR)   # carve the union of focus rects
        for rx, ry, rw, rh in rects:
            cr.rectangle(rx, ry, rw, rh)
        cr.fill()                                # nonzero winding -> union
        cr.set_operator(cairo.OPERATOR_OVER)
        cr.pop_group_to_source()
        cr.paint()
        cr.restore()

    def draw(self, cr, ctx):
        # No-op: combined darkening is drawn centrally (see draw_combined).
        pass

    def bbox(self):
        return (self.x, self.y, self.w, self.h)

    def set_bbox(self, x, y, w, h):
        self.x, self.y, self.w, self.h = x, y, w, h

    def move(self, dx, dy):
        self.x += dx; self.y += dy

    def contains(self, px, py, tol):
        # grab by the focus-rectangle border (interior stays click-through)
        t = tol + 3
        outer = (self.x - t <= px <= self.x + self.w + t
                 and self.y - t <= py <= self.y + self.h + t)
        inner = (self.x + t < px < self.x + self.w - t
                 and self.y + t < py < self.y + self.h - t)
        return outer and not inner


# -------------------------------------------------------------- stroke shapes
@dataclass
class Pen(Annotation):
    points: List[Tuple[float, float]] = field(default_factory=list)
    color: str = "#ff3b30"
    width: float = 4

    def draw(self, cr, ctx):
        if len(self.points) < 2:
            return
        _set_color(cr, self.color)
        cr.set_line_width(self.width)
        cr.set_line_cap(1)
        cr.set_line_join(1)
        cr.move_to(*self.points[0])
        for p in self.points[1:]:
            cr.line_to(*p)
        cr.stroke()

    def bbox(self):
        if not self.points:
            return (0, 0, 0, 0)
        xs = [p[0] for p in self.points]; ys = [p[1] for p in self.points]
        return (min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))

    def set_bbox(self, x, y, w, h):
        ox, oy, ow, oh = self.bbox()
        sx = w / ow if ow else 1
        sy = h / oh if oh else 1
        self.points = [(x + (px - ox) * sx, y + (py - oy) * sy)
                       for px, py in self.points]

    def move(self, dx, dy):
        self.points = [(px + dx, py + dy) for px, py in self.points]

    def contains(self, px, py, tol):
        t = tol + self.width / 2
        for a, b in zip(self.points, self.points[1:]):
            if _dist_to_segment(px, py, a[0], a[1], b[0], b[1]) <= t:
                return True
        return False


@dataclass
class Highlight(Pen):
    color: str = "#ffea00"
    width: float = 22
    # A marker stroke is defined by where you dragged it, not by a box: scaling
    # one just smears it. Highlights can be selected, moved and deleted, but not
    # resized, so they get a frame with no handles.
    handle_style = "none"

    def draw(self, cr, ctx):
        if len(self.points) < 2:
            return
        cr.push_group()
        _set_color(cr, self.color, 1.0)
        cr.set_line_width(self.width)
        cr.set_line_cap(2)  # square
        cr.set_line_join(1)
        cr.move_to(*self.points[0])
        for p in self.points[1:]:
            cr.line_to(*p)
        cr.stroke()
        cr.pop_group_to_source()
        cr.paint_with_alpha(0.4)


# --------------------------------------------------------------- text/counter
@dataclass
class Text(Annotation):
    """A text box rendered with Pango.

    - Font size is set explicitly (never by resizing the box).
    - `box_w` is the wrap width: None = auto (grows with content, floored at a
      minimum); a number = manual width (text wraps, height grows to fit).
    - `align` is one of left / center / right / justify.
    """
    x: float; y: float; text: str = ""
    color: str = "#ff3b30"
    size: float = 28
    align: str = "left"
    font: str = "Sans"
    box_w: Optional[float] = None
    _w: float = 0.0   # last rendered text width  (cache for bbox / handles)
    _h: float = 0.0   # last rendered text height (cache for bbox / handles)

    PAD = 12.0        # breathing room between the text and the box frame

    def min_width(self):
        return max(48.0, self.size * 2.2)

    def build_layout(self, cr):
        """Configure a Pango layout for the current text/size/align/width and
        update the cached rendered size. Returns the layout."""
        layout = PangoCairo.create_layout(cr)
        fd = Pango.FontDescription()
        fd.set_family(self.font or "Sans")
        fd.set_weight(Pango.Weight.BOLD)
        fd.set_absolute_size(self.size * Pango.SCALE)
        layout.set_font_description(fd)
        layout.set_text(self.text or "", -1)
        # natural (unwrapped) width first
        layout.set_width(-1)
        natural = layout.get_pixel_extents()[1].width
        eff = self.box_w if self.box_w else max(natural, self.min_width())
        layout.set_width(int(eff * Pango.SCALE))
        layout.set_alignment(_PANGO_ALIGN.get(self.align, Pango.Alignment.LEFT))
        layout.set_justify(self.align == "justify")
        if self.box_w:
            layout.set_wrap(Pango.WrapMode.WORD_CHAR)
        log = layout.get_pixel_extents()[1]
        self._w = eff
        self._h = log.height
        return layout

    def draw(self, cr, ctx):
        layout = self.build_layout(cr)
        _set_color(cr, self.color)
        cr.move_to(self.x + self.PAD, self.y + self.PAD)  # inset from the frame
        PangoCairo.show_layout(cr, layout)

    def bbox(self):
        # The box is the text plus PAD on every side, so the frame never hugs
        # the glyphs.
        w = (self._w or (self.box_w or self.min_width())) + 2 * self.PAD
        h = (self._h or (self.size * 1.4)) + 2 * self.PAD
        return (self.x, self.y, w, h)

    def set_bbox(self, x, y, w, h):
        # Resizing sets the wrap WIDTH only — never the font size; height is
        # content-driven. The frame width includes padding, so subtract it.
        self.x, self.y = x, y
        self.box_w = max(self.min_width(), w - 2 * self.PAD)

    def move(self, dx, dy):
        self.x += dx; self.y += dy

    # ------------------------------------------------------ caret / selection
    # The editor needs to map between character indices and on-canvas positions
    # so the caret can be placed, moved with the arrow keys and dragged over to
    # select a range. Pango works in UTF-8 byte offsets; the editor works in
    # character indices, so everything converts here.
    def layout(self, cr=None):
        return self.build_layout(cr if cr is not None else measure_cr())

    def index_to_byte(self, idx):
        return len((self.text or "")[:idx].encode("utf-8"))

    def byte_to_index(self, b):
        raw = (self.text or "").encode("utf-8")[:max(0, b)]
        return len(raw.decode("utf-8", "ignore"))

    @staticmethod
    def _prev_byte(raw, i):
        """Step back one UTF-8 character boundary from byte offset `i`."""
        i -= 1
        while i > 0 and (raw[i] & 0xC0) == 0x80:
            i -= 1
        return max(0, i)

    def caret_rect(self, idx, cr=None):
        """(x, y, height) of the caret sitting before character `idx`, in image
        coordinates."""
        layout = self.layout(cr)
        pos = layout.index_to_pos(self.index_to_byte(idx))
        return (self.x + self.PAD + pos.x / Pango.SCALE,
                self.y + self.PAD + pos.y / Pango.SCALE,
                (pos.height / Pango.SCALE) or self.size)

    def index_at(self, px, py, cr=None):
        """Character index nearest the image-space point (px, py)."""
        layout = self.layout(cr)
        lx = int((px - self.x - self.PAD) * Pango.SCALE)
        ly = int((py - self.y - self.PAD) * Pango.SCALE)
        _inside, bidx, trailing = layout.xy_to_index(lx, ly)
        return max(0, min(len(self.text or ""),
                          self.byte_to_index(bidx) + (trailing or 0)))

    def line_of(self, idx, cr=None):
        """(line_number, line) for the visual line holding character `idx`."""
        layout = self.layout(cr)
        line_no, _x = layout.index_to_line_x(self.index_to_byte(idx), False)
        return line_no, layout.get_line_readonly(line_no)

    def selection_rects(self, i0, i1, cr=None):
        """Image-space rectangles covering characters [i0, i1) — one per visual
        line, so a multi-line selection highlights correctly."""
        if i0 == i1:
            return []
        layout = self.layout(cr)
        raw = (self.text or "").encode("utf-8")
        b0 = self.index_to_byte(min(i0, i1))
        b1 = self.index_to_byte(max(i0, i1))
        out = []
        it = layout.get_iter()
        while True:
            line = it.get_line_readonly()
            ls, ll = line.start_index, line.length
            ly0, ly1 = it.get_line_yrange()
            s, e = max(b0, ls), min(b1, ls + ll)
            if ll == 0:
                # A blank line: show a slim marker when it falls inside the range.
                if b0 <= ls < b1:
                    x0 = layout.index_to_pos(ls).x / Pango.SCALE
                    x1 = x0 + self.size * 0.35
                else:
                    x0 = x1 = 0.0
            elif s < e:
                x0 = layout.index_to_pos(s).x / Pango.SCALE
                if e >= ls + ll:
                    # Selection runs to the end of this line: use the right edge
                    # of its last glyph (alignment-aware, unlike line extents).
                    p = layout.index_to_pos(self._prev_byte(raw, ls + ll))
                    x1 = (p.x + p.width) / Pango.SCALE
                else:
                    x1 = layout.index_to_pos(e).x / Pango.SCALE
            else:
                x0 = x1 = 0.0
            if x1 > x0:
                out.append((self.x + self.PAD + min(x0, x1),
                            self.y + self.PAD + ly0 / Pango.SCALE,
                            abs(x1 - x0), (ly1 - ly0) / Pango.SCALE))
            if not it.next_line():
                break
        return out


@dataclass
class Counter(Annotation):
    x: float; y: float; number: int = 1
    color: str = "#ff3b30"
    radius: float = 18

    def draw(self, cr, ctx):
        _set_color(cr, self.color)
        cr.arc(self.x, self.y, self.radius, 0, 2 * math.pi)
        cr.fill()
        cr.set_source_rgb(1, 1, 1)
        cr.select_font_face("sans-serif", 0, 1)
        cr.set_font_size(self.radius * 1.2)
        label = str(self.number)
        ext = cr.text_extents(label)
        cr.move_to(self.x - ext.width / 2 - ext.x_bearing,
                   self.y - ext.height / 2 - ext.y_bearing)
        cr.show_text(label)

    def bbox(self):
        return (self.x - self.radius, self.y - self.radius,
                2 * self.radius, 2 * self.radius)

    def set_bbox(self, x, y, w, h):
        self.radius = max(6, min(w, h) / 2)
        self.x = x + w / 2
        self.y = y + h / 2

    def move(self, dx, dy):
        self.x += dx; self.y += dy

    def contains(self, px, py, tol):
        return math.hypot(px - self.x, py - self.y) <= self.radius + tol
